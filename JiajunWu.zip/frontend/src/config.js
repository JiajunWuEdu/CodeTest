const API_URL = "http://"+window.location.hostname+":8008/";

export { API_URL };