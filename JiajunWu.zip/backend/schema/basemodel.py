from pydantic import BaseModel


class basemodel(BaseModel):
    pass
