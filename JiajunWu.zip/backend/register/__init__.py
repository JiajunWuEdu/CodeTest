from .static import register_static
from .db import register_db
from .exception import register_exception
from .cors import register_cors
from .logger import register_logger
from .router import register_router
